// sequence2.cpp
// Member-function definitions for class sequence

// Name: Lawrence Cole
// Assignement#: A2
// Purpose: sequence member-function definitions. This file contains
//          implementations of the member functions prototyped in sequence2.h
//     Course: CISP 430 S23
// File Name: sequence2.cpp

// 170/200 - Fails Test 2

#include "sequence2.h"
#include <cassert>
#include <algorithm>

using namespace CISP430_A2;

namespace CISP430_A2
{
    sequence::sequence(size_type entry) 
    {
        data = new value_type[entry];
        used = 0;
        capacity = entry;
        current_index = 0;
    }
    sequence::sequence(const sequence& entry) 
    {
        data = new value_type[entry.capacity];
        capacity = entry.capacity;
        used = entry.used;
        current_index = entry.current_index;

        std::copy(entry.data, entry.data + used, data);
    }

    void sequence::start() 
    {
        if (used > 0) {
            current_index = 0;
        }
    }
    void sequence::advance() 
    {
        if (is_item()) {
            ++current_index;
        }
    }
    void sequence::insert(const value_type& entry) 
    {
        if (used == capacity) {
            size_type new_capacity = capacity * 1.1;
            resize(new_capacity);
        }
        if (!is_item()) {
            // If there is no current item, insert at the front
            current_index = 0;
        }
        else {
            // Otherwise, shift all items to the right of current index to make room
            for (size_type i = used; i > current_index; --i) {
                data[i] = data[i - 1];
            }
        }
        // Insert the new item at the current index
        data[current_index] = entry;
        ++used;
    }
    void sequence::attach(const value_type& entry) 
    {
        if (used == capacity) {
            size_type new_capacity = capacity * 1.1;
            resize(new_capacity);
        }
        if (!is_item()) {
            data[used] = entry;
            used++;
            current_index = used - 1;
        }
        else {
            for (size_type i = used; i > current_index + 1; i--) {
                data[i] = data[i - 1];
            }
            current_index++;
            data[current_index] = entry;
            used++;
        }
    }
    void sequence::remove_current() 
    {
        assert(is_item());

        if (current_index == used - 1) {
            --used;
            current_index = used;
        }
        else {
            for (size_type i = current_index; i < used - 1; ++i)
                data[i] = data[i + 1];

            --used;
        }
    }
    void sequence::resize(size_type new_capacity)
    {
        if (new_capacity <= used) {
            return;
        }
        value_type* new_data = new value_type[new_capacity];
        for (size_type i = 0; i < used; ++i) {
            new_data[i] = data[i];
        }
        delete[] data;
        data = new_data;
        capacity = new_capacity;
    } 


    void sequence::operator =(const sequence& other)
    {
        // avoid self-assignment
        if (this != &other) 
        {  
            value_type* new_data = new value_type[other.capacity];
            delete[] data;

            data = new_data;
            used = other.used;
            capacity = other.capacity;
            current_index = other.current_index;
            std::copy(other.data, other.data + other.used, data);
        }
    }

    sequence::size_type sequence::size() const 
    {
        return used;
    }
    bool sequence::is_item() const 
    {
        return (current_index < used);
    }
    sequence::value_type sequence::current() const
    {
        if (is_item()) 
            return data[current_index];
    }


    sequence::~sequence() 
    {
        delete[] data; 
        data = nullptr;
        used = 0;
        capacity = 0;
        current_index = 0;
    }
}
