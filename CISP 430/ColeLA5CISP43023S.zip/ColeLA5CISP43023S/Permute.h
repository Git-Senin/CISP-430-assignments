#pragma once
#include "Node.h"
class Permute
{
public:
    Permute(string, string);
    ~Permute();
    void Permutation();
    void Print();
    void permute(string&,int,int);
    void pushNode(Node*);
private:
    void swap(char&, char&);

    Node* firstNode;
    Node* lastNode;
    string firstString;
    string secondString;
    int total;
};

