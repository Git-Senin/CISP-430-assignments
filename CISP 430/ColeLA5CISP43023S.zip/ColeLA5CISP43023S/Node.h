#pragma once
#include <iostream>
#include <string>
using std::string;

class Node
{
public:
    Node(string, Node*);
    inline Node* link() { return next; }
    inline std::string get() { return data; }
    void setLink(Node*);

private:
    string data;
    Node* next;
};

