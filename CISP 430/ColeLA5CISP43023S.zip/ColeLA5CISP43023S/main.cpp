#include "Permute.h"
using std::endl;
using std::cout;

int main() 
{
    Permute* perm[] = {
        new Permute("",""),
        new Permute("","CATMAN"),

        new Permute("C","ATMAN"),
        new Permute("CA","TMAN"),

        new Permute("CAT","MAN"),
        new Permute("CATM","AN"),

        new Permute("CATMA","N"),
        new Permute("CATMAN","")
    };

    cout << endl << endl;
    for (int i = 0; i < 8; i++) 
    {
        perm[i]->Print();
        cout << endl << endl;
    }
    return 0;
}