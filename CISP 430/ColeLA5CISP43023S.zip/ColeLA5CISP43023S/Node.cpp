#include "Node.h"

Node::Node(string s, Node* n) {
    data = s;
    next = n;
}

void Node::setLink(Node* link) {
    next = link;
}