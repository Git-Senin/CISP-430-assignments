#include "Permute.h"
using std::cout;
using std::endl;

// Constructor
Permute::Permute(string str1, string str2) 
{
    firstNode = nullptr;
    lastNode = nullptr;
    firstString = str1;
    secondString = str2;
    total = 0;
    Permutation();
}

// Deconstructor
Permute::~Permute() 
{
    // Delete while itterating
    Node* temp = nullptr;
    Node* current = firstNode;
    while (current != NULL) 
    {
        // track for deletion
        temp = current;
        current = current->link();

        // Deletion
        delete temp;
    }
}

// Starts Permutation
void Permute::Permutation()
{
    permute(firstString, 0, firstString.length() - 1);
}

// Prints List
void Permute::Print() 
{
    cout << "String 1 for this object is: " << firstString << endl;
    cout << "String 2 for this object is: " << secondString << endl;
    if (total <= 0) 
    {
        if (secondString.empty())
            cout << "There is no permutation." << endl << endl;
        else {
            cout << "The total possible permutation is " << total + 1 << endl;
            cout << "That is:" << endl << secondString;
        }
    }
    else 
    {
        cout << "The total possible permutation is " << total << endl;
        cout << ((total < 2) ? "That is: " : "They are: ") << endl;
        Node* current = firstNode;
        for (int i = 0; i < total; i++)
        {
            cout << current->get() << "  ";
            current = current->link();

            if (total < 100) {
                if (i % 4 == 3)
                    cout << endl;
            }
            else {
                if (i % 9 == 8)
                    cout << endl;
            }
        }
    }
}

// Util
// Swaps Chars
void Permute::swap(char &c1, char &c2) 
{
    char temp = c1;
    c1 = c2;
    c2 = temp;
}

// Recursive permute
// Pushes new permutations onto list
void Permute::permute(string &str, int l, int r) 
{
    // Base case
    if (l == r) 
    {
        Node* newNode = new Node(str + secondString, NULL);
        pushNode(newNode);
        total++;
    }
    else {
        // Permutations made
        for (int i = l; i <= r; i++) {

            // Swapping done
            swap(str[l], str[i]);

            // Recursion called
            permute(str, l + 1, r);

            // backtrack
            swap(str[l], str[i]);
        
        }
    }
}

// Util
// Pushes node onto list
void Permute::pushNode(Node* newNode) {
    if (total <= 0) {
        firstNode = newNode;
        lastNode = newNode;
    }
    else {
        lastNode->setLink(newNode);
        lastNode = newNode;
    }
}