// stats.cpp
// Member-function definitions for class statistician

// Name: Lawrence Cole
// Assignement#: A1
// Purpose: statistician member-function definitions. This file contains
//          implementations of the member functions prototyped in stats.h
//     Course: CISP 430 S23
// File Name: stats.cpp

#include <cassert> 
#include "stats.h"
using namespace CISP430_A1;

namespace CISP430_A1 
{
    statistician::statistician()
    {
        // Default constructor for statistician class
        // Resets all member variables to their initial state
        reset();
    }

    void statistician::next(double r)
    {
        // Adds a new number to the sequence of numbers being tracked by the statistician.
        total += r;
        count++;
        if (count == 1 || (r < tiniest))
            tiniest = r;
        if (count == 1 || (r > largest))
            largest = r;
    }

    void statistician::reset() 
    {
        // Resets all member variables to their initial state.
        count = 0;
        total = 0;
    }

    double statistician::mean() const
    {
        // Calculates and returns the mean of the numbers in the sequence.
        // Asserts that the sequence is not empty
        assert(length() > 0);
        return total / count;
    }
    double statistician::minimum() const
    {
        // Returns the smallest number in the sequence.
        // Asserts that the sequence is not empty
        assert(length() > 0);
        return tiniest;
    }
    double statistician::maximum() const
    {
        // Returns the largest number in the sequence.
        // Asserts that the sequence is not empty
        assert(length() > 0); 
        return largest;
    }
    statistician operator +(const statistician& s1, const statistician& s2)
    {
        // Adds all values in the given statisticians.
        statistician answer;
        // If the count of s1 is 0
        if (s1.count == 0) 
            answer = s2;
        // if the count of s2 is 0
        else if (s2.count == 0)
            answer = s1;
        else 
        {
            answer.count = s1.count + s2.count; 
            answer.total = s1.total + s2.total; 
            answer.tiniest = (s1.tiniest <= s2.tiniest) ? s1.tiniest : s2.tiniest; 
            answer.largest = (s1.largest >= s2.largest) ? s1.largest : s2.largest;
        }
        return answer;
    }
    statistician operator *(double scale, const statistician& s)
    {
        // Multiplies all values in the given statistician by the given scale.
        statistician answer;
        answer.count = s.count; 
        answer.total = scale * s.total; 
        // if scale is greater than or equal to 0
        if (scale >= 0) {
            answer.tiniest = scale * s.tiniest; 
            answer.largest = scale * s.largest; 
        }
        // if scale is less than 0
        else {
            answer.tiniest = scale * s.largest; 
            answer.largest = scale * s.tiniest; 
        }
        return answer;
    }

    bool operator==(const statistician& s1, const statistician& s2)
    {
        // Checking if both statisticians are empty
        if ((s1.length() == 0) || (s2.length() == 0))
            return (s1.length() == 0) && (s2.length() == 0);
        // If both are not empty, comparing all statistics
        else
            return (s1.length() == s2.length())
            && (s1.mean() == s2.mean())
            && (s1.minimum() == s2.minimum())
            && (s1.maximum() == s2.maximum())
            && (s1.sum() == s2.sum());
    }
}
