#include <iostream>
#include <cstdlib>
#include <ctime>
#include <random>

#include "table2.h"
using std::cout;
using std::endl;
struct Test_Record {
    int key;
};
void printDivider(int style = 0) {
    if (style == 0) {
        cout<< "----------------------------------------------------------------------------" << endl;
    }
    else {
        cout<< "=============================================================================" << endl;
    }
}
void printl(int n = 1) {
    for (int i = 0; i < n; i++)
        cout<< endl;
}
void printHeader(int i, size_t size) {
    cout << "\tTotal records in the " << (i == 1 ? "first":"second") << " Table object is " << size << endl
        << "\tContains of the " << (i == 1 ? "first" : "second") << " object display at below:" << endl;
}
int main() 
{   

    // Instantiate two Table objects each with 10 fields
        Table<Test_Record> table1 = Table<Test_Record>();
        Table<Test_Record> table2 = Table<Test_Record>();
        cout<< "Instantiate two Table objects." << endl;
        printl(1);

    // Display the two Table objects' information.
        printHeader(1, table1.size());
        for (int i = 0; i < table1.CAPACITY; i++) 
            table1.print(i);
        printDivider();

        printHeader(2, table2.size());
        for (int i = 0; i < table2.CAPACITY; i++)
            table2.print(i);
        printDivider(1);

        printl(3);

    // Use random number generator to generate 70 numbers eachn in between
    // 0~200 for the Table objects
    // Display the two Table objects' information
        cout<< "**Using random number generator generates 70 numbers each for the objects.**" << endl;
        printl(2);

        // Table 1
        std::srand(static_cast<unsigned int>(time(0)));
        for (int i = 0; i < 70; i++)
        {
            Test_Record record;
            record.key = rand() % 200 + 1;
            table1.insert(record);
        }
        printHeader(1, table1.size());
        for (int i = 0; i < table1.CAPACITY; i++)
            table1.print(i);
        printDivider();

        // Table 2
        std::random_device rd;
        std::srand(rd());
        for (int i = 0; i < 70; i++)
        {
            Test_Record record;
            record.key = rand() % 200 + 1;
            table2.insert(record);
        }
        printHeader(2, table2.size());
        for (int i = 0; i < table2.CAPACITY; i++)
            table2.print(i);
        printDivider(1);

    // Removes all the data in first object
    // Display the two Table objects' information
        printl(3);
        cout << "** Calling remove function removes all the contents in first object. **" << endl;
        printl(2);
        table1.clear();

        printHeader(1, table1.size());
        for (int i = 0; i < table1.CAPACITY; i++)
            table1.print(i);
        printDivider();

        printHeader(2, table2.size());
        for (int i = 0; i < table2.CAPACITY; i++)
            table2.print(i);
        printDivider(1);

    // Using = to assign 2nd object to the first one
    // Display the two Table objects' information
        printl(3);
        cout << "** Using TBObject1 = TBObject2 displays the assignment operator overloading. **" << endl;
        printl(2);

        table1 = table2;

        printHeader(1, table1.size());
        for (int i = 0; i < table1.CAPACITY; i++)
            table1.print(i);
        printDivider();

        printHeader(2, table2.size());
        for (int i = 0; i < table2.CAPACITY; i++)
            table2.print(i);
        printDivider(1);

    printl(3);
    return 0;
}