// FILE: table2.h

#ifndef TABLE2_H
#define TABLE2_H
#include <assert.h>
#include <iostream>
#include "link2.h"

    template <class RecordType>
    class Table 
    {
    public:
        static const size_t CAPACITY = 10;
        // Constructor
        Table();

        // Insert
        void insert(const RecordType& entry);

        // remove
        void remove(int key);
        // clear
        void clear();
        // print 
        void print(int index)const;

        // is present
        bool is_present(const RecordType& target) const;

        // find
        void find(int key, bool& found, RecordType& result) const;

        // size
        size_t size() const;

        // Overload Operator
        Table<RecordType>& operator=(const Table<RecordType>& other);

    private:
        Node<RecordType>* data[CAPACITY];
        size_t total_records;

        // Helper functions
        size_t hash(int key) const;
        Node<RecordType>* find_node(Node<RecordType>*& cursor, Node<RecordType>*& precursor, int key);
    };
    
#include "table2.template"
#endif
