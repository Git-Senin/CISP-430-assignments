#include "pqueue1.h"
// Name: Lawrence Cole
// Assignment: A4

PriorityQueue::PriorityQueue() 
{
    head_ptr = nullptr;
    many_nodes = 0;
}

PriorityQueue::PriorityQueue(const PriorityQueue& source) 
{
    // Save Old Queue for deletion
    Node* old_head_ptr = head_ptr;
    head_ptr = nullptr;
    many_nodes = source.many_nodes;

    // Copy
    Node* new_head_ptr = source.head_ptr;
    Node* dest = nullptr;
    while (new_head_ptr != NULL) 
    {
        // Create Node
        Node* new_node = new Node;
        new_node->data      = new_head_ptr->data;
        new_node->priority  = new_head_ptr->priority;
        new_node->link      = nullptr;
        
        if (dest == nullptr)
            head_ptr = new_node;
        else
            dest->link = new_node;

        // Next
        dest = new_node;
        new_head_ptr = new_head_ptr->link;
    }
    
    // Deletion
    Node* old_node = nullptr;
    while (old_head_ptr != NULL) 
    {
        old_node = old_head_ptr;
        old_head_ptr = old_head_ptr->link;
        delete old_node;
    }
}

PriorityQueue::~PriorityQueue() 
{
    // Iterate thru Queue
    Node* current = head_ptr;
    while (current != nullptr)
    {
        Node* temp = current;
        current = current->link;
        delete temp;
    }
    head_ptr = nullptr;
    many_nodes = 0;
}

void PriorityQueue::operator =(const PriorityQueue& source) 
{
    // Avoid Self Assignment
    if (source.head_ptr == head_ptr) return;

    // Delete current list
    while (head_ptr != nullptr) {
        Node* old_head_ptr = head_ptr;
        head_ptr = head_ptr->link;
        delete old_head_ptr;
    }

    // Create new list from source
    if (source.head_ptr == nullptr) 
    {
        head_ptr = nullptr;
        many_nodes = 0;
    }
    else 
    {
        head_ptr = new Node;
        head_ptr->data = source.head_ptr->data;
        head_ptr->priority = source.head_ptr->priority;

        Node* new_node = head_ptr;
        Node* source_node = source.head_ptr->link;

        while (source_node != nullptr) 
        {
            new_node->link = new Node;
            new_node = new_node->link;
            new_node->data = source_node->data;
            new_node->priority = source_node->priority;
            source_node = source_node->link;
        }

        new_node->link = nullptr;
        many_nodes = source.many_nodes;
    }
}

void PriorityQueue::insert(const PriorityQueue::Item & entry, unsigned int priority) 
{
    // New Node
    Node* temp = new Node;
    temp->data = entry;
    temp->priority = priority;
    temp->link = nullptr;

    // Empty
    if (is_empty()) 
    {
        head_ptr = temp;
    }
    // Higher than Head Priority
    else if (head_ptr->priority < priority)
    {
        temp->link = head_ptr;
        head_ptr = temp;
    }
    // Base Case
    else
    {
        Node* current = head_ptr;
        // Find Priority Position
        while (current->link != NULL && current->link->priority > priority)
        {
            current = current->link;
        }
        // Find End Of Priority
        while (current->link != NULL && current->link->priority == priority) 
        {
            current = current->link;
        }
        // Set temp to next & current to temp
        temp->link = current->link;
        current->link = temp;
    }
    many_nodes++;
}

PriorityQueue::Item PriorityQueue::get_front()
{
    if (!is_empty()) 
    {
        // Get Item
        Item front = head_ptr->data;

        // Delete Front Node
        Node* old_head_ptr = head_ptr;
        head_ptr = head_ptr->link;
        delete old_head_ptr;
        many_nodes--;

        return front;
    }
}